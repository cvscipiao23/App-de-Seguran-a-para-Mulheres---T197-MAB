import React, { useState } from 'react';
import { View, TextInput, Text, TouchableOpacity, ScrollView } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './Styles';

 function TelaCadastro({ navigation }) {
   
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');

  return (
    <View style={styles.container_contato}>
      <ScrollView 
        contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', alignItems: 'center', width: '100%' }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.card_cadastro}>
          
          
          <View style={styles.logoContainer}>
            <MaterialCommunityIcons 
              name="map-marker" 
              size={50} 
              color="#8e2de2" 
            />
            <Text style={styles.logoText}>SafeHer</Text>
            <Text style={[styles.texto, { marginBottom: 10 }]}>Crie sua conta</Text>
          </View>

          {/* Campo Nome */}
          <TextInput
            style={styles.input_cadastro}
            placeholder="Nome Completo"
            value={nome}
            onChangeText={setNome}
          />

          {/* Campo Email */}
          <TextInput
            style={styles.input_cadastro}
            placeholder="E-mail"
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
          />

          {/* Campo Senha */}
          <TextInput
            style={styles.input_cadastro}
            placeholder="Senha"
            secureTextEntry
            value={senha}
            onChangeText={setSenha}
          />

          {/* Campo Confirmar Senha */}
          <TextInput
            style={styles.input_cadastro}
            placeholder="Confirmar Senha"
            secureTextEntry
            value={confirmarSenha}
            onChangeText={setConfirmarSenha}
          />

          {/* Botão de Cadastro */}
          <TouchableOpacity 
            style={styles.botao}
            onPress={() => alert('Cadastro realizado com sucesso!')}
          >
            <Text style={styles.texto_botao}>CADASTRAR</Text>
          </TouchableOpacity>

          {/* Voltar para o Login */}
          <TouchableOpacity 
            style={styles.criarConta}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.texto_criar}>Já tem uma conta? Entre aqui</Text>
          </TouchableOpacity>

        </View>
      </ScrollView>
    </View>
  );
}
export default TelaCadastro;