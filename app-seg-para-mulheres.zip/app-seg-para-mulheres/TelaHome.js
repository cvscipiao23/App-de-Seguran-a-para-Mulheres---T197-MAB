import React from 'react';
import { View, Text, TouchableOpacity, Linking } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './Styles';

export default function TelaHome({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={styles.card_home}>
      
      {/* Logo */}
      <View style={styles.logoContainer}>
        <MaterialCommunityIcons 
          name="map-marker" 
          size={80} 
          color="#8e2de2" 
        />
        <Text style={styles.logoText}>SafeHer</Text>
      </View>

      <Text style={styles.texto}>Bem-vinda de volta!</Text>

      {/* botão de login principal */}

      <TouchableOpacity 
        style={styles.botao}
        onPress={() => navigation.navigate('Login')}
      >
        <Text style={styles.texto_botao}>ENTRAR</Text>
      </TouchableOpacity>

      {/* seção de cadastro */}

      <Text style={styles.idade}>Ainda não tem uma conta?</Text> 
      
      <TouchableOpacity 
        style={styles.botao2}
        onPress={() => navigation.navigate('Cadastro')}
      >
        <Text style={styles.texto_botao_outline}>CRIAR CONTA</Text>
      </TouchableOpacity>


      {/* social */}
      <TouchableOpacity>
        <Text style={styles.texto_instituicao}>Precisa de ajuda?</Text>
      </TouchableOpacity>

    <View style={styles.socialContainer}>
        {/* Facebook */}
        <TouchableOpacity onPress={() => Linking.openURL('https://www.facebook.com')}>
          <MaterialCommunityIcons name="facebook" size={40} color="#8e2de2" />
        </TouchableOpacity>

        {/* Instagram */}
        <TouchableOpacity 
          style={{ marginLeft: 20 }} 
          onPress={() => Linking.openURL('https://www.instagram.com')}
        >
          <MaterialCommunityIcons name="instagram" size={40} color="#8e2de2" />
        </TouchableOpacity>
      </View>
    </View>
    </View>
  );
}