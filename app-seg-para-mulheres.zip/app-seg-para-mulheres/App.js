import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import TelaHome from './TelaHome';
import TelaLogin from './TelaLogin';
import TelaCadastro from './TelaCadastro';

const Stack = createStackNavigator();

  export default function App() {
      return (
        <NavigationContainer>
        <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={TelaHome} />
        <Stack.Screen name="Login" component={TelaLogin} />
        <Stack.Screen name="Cadastro" component={TelaCadastro} />
        </Stack.Navigator>
        </NavigationContainer>
);
}