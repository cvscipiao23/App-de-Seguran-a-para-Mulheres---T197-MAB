import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  //  CONTAINERS 
  container: { 
    flex: 1,
    backgroundColor: 'pink',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  container_contato: {
    flex: 1,
    backgroundColor: 'pink',
    justifyContent: 'center',
    alignItems: 'center',
  },
  card_login: {
    width: '75%',
    backgroundColor: 'pink',
    borderRadius: 25,
    padding: 20,
  },
  card_cadastro: {
    width: '105%',
    backgroundColor: 'pink',
    borderRadius: 25,
    padding: 20,
  },
   card_home: {
    width: '100%',
    backgroundColor: 'pink',
    borderRadius: 25,
    padding: 20,
  },

  // --- LOGO E TEXTOS ---
  logoContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logoText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#8e2de2',
  },
  texto: {
    fontSize: 18,
    color: '#6a1b9a',
    marginBottom: 20,
    textAlign: 'center',
    fontWeight: '500',
  },

  // INPUTS 
  
  input_login: {
    height: 50,
    backgroundColor: '#eee',
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 15,
    fontSize: 16,
    color: '#333',
  },

  
  input_cadastro: {
    height: 55,                
    backgroundColor: '#ececec', 
    borderRadius: 15,          
    marginBottom: 15,          
    paddingHorizontal: 20,    
    fontSize: 16,
    color: '#333',
    width: '100%',             
  },

  // BOTÕES
  botao: {
    backgroundColor: '#8e2de2',
    height: 50,
    width: '100%',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
  botao2: { 
    borderWidth: 2,
    borderColor: '#8e2de2',
    height: 50,
    width: '100%',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 15,
  },
  texto_botao: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
    textTransform: 'uppercase',
  },
  texto_botao_outline: {
    color: '#8e2de2',
    fontWeight: 'bold',
    fontSize: 16,
    textTransform: 'uppercase',
  },

  //  LINKS E SOCIAL 
  
  idade: {
    marginTop: 20,
    color: '#6a1b9a',
    fontSize: 14,
    textAlign: 'center',
  },
  texto_instituicao: {
    marginTop: 30,
    color: '#6a1b9a',
    textDecorationLine: 'underline',
    fontWeight: 'bold',
  },
  socialContainer: {
    flexDirection: 'row',
    marginTop: 25,
    justifyContent: 'center',
    width: '100%',
  },
  criarConta: {
    marginTop: 15,
    alignItems: 'center',
  },
  texto_criar: {
    color: '#6a1b9a',
    textDecorationLine: 'underline',
    fontWeight: '500',
  },
});

export default styles;