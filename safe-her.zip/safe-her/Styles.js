import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  //  CONTAINERS 
  container: { 
    flex: 1,
    backgroundColor: 'pink',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  container_contato: {
    flex: 1,
    backgroundColor: 'pink',
    justifyContent: 'center',
    alignItems: 'center',
  },
  card_login: {
    width: '75%',
    backgroundColor: 'pink',
    borderRadius: 25,
    padding: 20,
  },
  card_cadastro: {
    width: '105%',
    backgroundColor: 'pink',
    borderRadius: 25,
    padding: 20,
  },
   card_home: {
    width: '100%',
    backgroundColor: 'pink',
    borderRadius: 25,
    padding: 20,
  },

  // --- LOGO E TEXTOS ---
  logoContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logoText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#8e2de2',
  },
  texto: {
    fontSize: 18,
    color: '#6a1b9a',
    marginBottom: 20,
    textAlign: 'center',
    fontWeight: '500',
  },

  // INPUTS 
  
  input_login: {
    height: 50,
    backgroundColor: '#eee',
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 15,
    fontSize: 16,
    color: '#333',
  },

  
  input_cadastro: {
    height: 55,                
    backgroundColor: '#ececec', 
    borderRadius: 15,          
    marginBottom: 15,          
    paddingHorizontal: 20,    
    fontSize: 16,
    color: '#333',
    width: '100%',             
  },

  // BOTÕES
  botao: {
    backgroundColor: '#8e2de2',
    height: 50,
    width: '100%',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
  botao2: { 
    borderWidth: 2,
    borderColor: '#8e2de2',
    height: 50,
    width: '100%',
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 15,
  },
  texto_botao: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
    textTransform: 'uppercase',
  },
  texto_botao_outline: {
    color: '#8e2de2',
    fontWeight: 'bold',
    fontSize: 16,
    textTransform: 'uppercase',
  },

  //  LINKS E SOCIAL 
  
  idade: {
    marginTop: 20,
    color: '#6a1b9a',
    fontSize: 14,
    textAlign: 'center',
  },
  texto_instituicao: {
    marginTop: 30,
    color: '#6a1b9a',
    textDecorationLine: 'underline',
    fontWeight: 'bold',
  },
  socialContainer: {
    flexDirection: 'row',
    marginTop: 25,
    justifyContent: 'center',
    width: '100%',
  },
  criarConta: {
    marginTop: 15,
    alignItems: 'center',
  },
  texto_criar: {
    color: '#6a1b9a',
    textDecorationLine: 'underline',
    fontWeight: '500',
  },
  container_inicio: {
  flex: 1,
  backgroundColor: '#f2f2f2',
  justifyContent: 'center',
  alignItems: 'center',
},

card_inicio: {
  width: '90%',
  backgroundColor: '#f8c8dc',
  borderRadius: 25,
  padding: 20,
  alignItems: 'center',
  elevation: 5,
},

botao_emergencia: {
  width: '100%',
  backgroundColor: '#d32f2f',
  padding: 15,
  borderRadius: 15,
  alignItems: 'center',
  marginBottom: 20,
},

texto_emergencia: {
  color: 'white',
  fontWeight: 'bold',
  fontSize: 20,
},

linha_botoes: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  width: '100%',
  marginBottom: 20,
},

botao_registrar: {
  width: '48%',
  backgroundColor: '#d81b60',
  padding: 15,
  borderRadius: 15,
  alignItems: 'center',
},

botao_mapa_inicio: {
  width: '48%',
  backgroundColor: '#26a69a',
  padding: 15,
  borderRadius: 15,
  alignItems: 'center',
},

texto_botao_inicio: {
  color: 'white',
  textAlign: 'center',
  marginTop: 5,
  fontWeight: 'bold',
},

botao_contatos: {
  width: '100%',
  backgroundColor: '#e53935',
  padding: 15,
  borderRadius: 15,
  alignItems: 'center',
  flexDirection: 'row',
  justifyContent: 'center',
},

texto_contatos: {
  color: 'white',
  fontWeight: 'bold',
  fontSize: 16,
  marginLeft: 10,
},
container_principal: {
  flex: 1,
  backgroundColor: '#f8c8dc',
  justifyContent: 'center',
  alignItems: 'center',
},

card_principal: {
  width: '90%',
  backgroundColor: '#f8c8dc',
  borderRadius: 25,
  padding: 20,
  alignItems: 'center',
},
texto_esqueceu: {
  color: '#6a1b9a',
  textAlign: 'center',
  marginTop: 10,
  textDecorationLine: 'underline',
},
container_recuperar: {
  flex: 1,
  backgroundColor: '#e5a0ad',
  justifyContent: 'center',
  alignItems: 'center',
  paddingHorizontal: 25,
},

titulo_recuperar: {
  fontSize: 28,
  fontWeight: 'bold',
  color: '#8e2de2',
  marginTop: 10,
},

subtitulo_recuperar: {
  color: '#6a1b9a',
  marginTop: 12,
  marginBottom: 25,
  textAlign: 'center',
},

input_recuperar: {
  width: '100%',
  height: 55,
  backgroundColor: 'white',
  borderRadius: 10,
  paddingHorizontal: 15,
  marginBottom: 20,
},

botao_recuperar: {
  width: '100%',
  height: 55,
  backgroundColor: '#8e2de2',
  borderRadius: 10,
  justifyContent: 'center',
  alignItems: 'center',
},

texto_botao_recuperar: {
  color: 'white',
  fontWeight: 'bold',
  fontSize: 15,
},

voltar_login: {
  color: '#6a1b9a',
  textDecorationLine: 'underline',
  marginTop: 25,
},

ajuda_texto: {
  color: '#6a1b9a',
  marginTop: 30,
  fontSize: 12,
},

redes_container: {
  flexDirection: 'row',
  gap: 15,
  marginTop: 10,
},
container_senha: {
  flexDirection: 'row',
  alignItems: 'center',
  backgroundColor: '#eee',
  borderRadius: 10,
  marginBottom: 15,
  paddingHorizontal: 10,
},

input_senha: {
  flex: 1,
  height: 50,
},
});

export default styles;