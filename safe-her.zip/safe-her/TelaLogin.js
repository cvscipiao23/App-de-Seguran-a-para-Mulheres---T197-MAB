import React, { useState } from 'react';
import { View, TextInput, Text, TouchableOpacity } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './Styles';

function TelaLogin({ navigation }) {

  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [mostrarSenha, setMostrarSenha] = useState(false); // 👈 ADICIONADO

  return (
    <View style={styles.container_contato}>

      <View style={styles.card_login}>

        {/* Logo */}
        <View style={styles.logoContainer}>
          <MaterialCommunityIcons 
            name="map-marker" 
            size={40} 
            color="#8e2de2" 
          />
          <Text style={styles.logoText}>SafeHer</Text>
        </View>

        {/* Input Email */}
        <TextInput
          style={styles.input_login}
          placeholder="E-mail"
          value={email}
          onChangeText={setEmail}
        />

        {/* Input Senha COM OLHINHO */}
        <View style={styles.container_senha}>
          <TextInput
            style={styles.input_senha}
            placeholder="Senha"
            value={senha}
            onChangeText={setSenha}
            secureTextEntry={!mostrarSenha}
          />

          <TouchableOpacity onPress={() => setMostrarSenha(!mostrarSenha)}>
            <MaterialCommunityIcons 
              name={mostrarSenha ? 'eye-off' : 'eye'} 
              size={25} 
              color="gray" 
            />
          </TouchableOpacity>
        </View>

        {/* Esqueceu senha */}
        <TouchableOpacity onPress={() => navigation.navigate('RecuperarSenha')}>
          <Text style={styles.texto_esqueceu}>Esqueceu sua senha?</Text>
        </TouchableOpacity>

        {/* Botão */}
        <TouchableOpacity 
          style={styles.botao}
          onPress={() => navigation.navigate('Principal')}
        >
          <Text style={styles.texto_botao}>Entrar</Text>
        </TouchableOpacity>

        {/* Criar conta */}
        <TouchableOpacity style={styles.criarConta}>
          <Text style={styles.texto_criar}>Criar conta</Text>
        </TouchableOpacity>

      </View>

    </View>
  );
}

export default TelaLogin;