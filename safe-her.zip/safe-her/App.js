import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import TelaHome from './TelaHome';
import TelaLogin from './TelaLogin';
import TelaCadastro from './TelaCadastro';
import TelaPrincipal from './TelaPrincipal'; // 👈 ADICIONEI
import TelaRecuperarSenha from './TelaRecuperarSenha';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={TelaHome} />
        <Stack.Screen name="Login" component={TelaLogin} />
        <Stack.Screen name="Cadastro" component={TelaCadastro} />

        {/* 👇 NOVA TELA */}
        <Stack.Screen name="Principal" component={TelaPrincipal} />
        <Stack.Screen name="RecuperarSenha" component={TelaRecuperarSenha} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
