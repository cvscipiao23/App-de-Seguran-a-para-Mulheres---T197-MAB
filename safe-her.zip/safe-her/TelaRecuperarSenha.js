import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './Styles';

function TelaRecuperarSenha({ navigation }) {
  const [email, setEmail] = useState('');

  return (
    <View style={styles.container_recuperar}>

      <MaterialCommunityIcons 
        name="map-marker" 
        size={70} 
        color="#8e2de2" 
      />

      <Text style={styles.titulo_recuperar}>SafeHer</Text>

      <Text style={styles.subtitulo_recuperar}>
        Digite seu e-mail para recuperar a sua senha
      </Text>

      <TextInput
        style={styles.input_recuperar}
        placeholder="Seu e-mail"
        placeholderTextColor="#888"
        value={email}
        onChangeText={setEmail}
      />

      <TouchableOpacity 
        style={styles.botao_recuperar}
        onPress={() => alert('E-mail enviado!')}
      >
        <Text style={styles.texto_botao_recuperar}>ENVIAR</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Login')}>
        <Text style={styles.voltar_login}>Voltar para login</Text>
      </TouchableOpacity>

      <Text style={styles.ajuda_texto}>Precisa de ajuda?</Text>

      <View style={styles.redes_container}>
        <MaterialCommunityIcons name="facebook" size={30} color="#8e2de2" />
        <MaterialCommunityIcons name="instagram" size={30} color="#8e2de2" />
      </View>

    </View>
  );
}

export default TelaRecuperarSenha;