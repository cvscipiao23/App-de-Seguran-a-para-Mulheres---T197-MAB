import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './Styles';

function TelaInicio({ navigation }) {

  return (
    <View style={styles.container_inicio}>

      <View style={styles.card_inicio}>

        {/* Botão emergência */}
        <TouchableOpacity style={styles.botao_emergencia}
        onPress={() => alert('alerta enviado para as autoridades')}>
          <Text style={styles.texto_emergencia}>EMERGÊNCIA</Text>
        </TouchableOpacity>

        {/* Linha com dois botões */}
        <View style={styles.linha_botoes}>

          <TouchableOpacity style={styles.botao_registrar}>
            <MaterialCommunityIcons name="file-document" size={30} color="white" />
            <Text style={styles.texto_botao_inicio}>Registrar{'\n'}Ocorrência</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.botao_mapa_inicio}
            onPress={() => navigation.navigate('Mapa')}
          >
            <MaterialCommunityIcons name="map-marker" size={30} color="white" />
            <Text style={styles.texto_botao_inicio}>Mapa</Text>
          </TouchableOpacity>

        </View>

        {/* Botão contatos */}
        <TouchableOpacity style={styles.botao_contatos}>
          <MaterialCommunityIcons name="account" size={30} color="white" />
          <Text style={styles.texto_contatos}>Contatos</Text>
        </TouchableOpacity>

      </View>

    </View>
  );
}

export default TelaInicio;