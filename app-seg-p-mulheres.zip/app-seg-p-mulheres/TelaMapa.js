import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, Platform } from 'react-native';
import * as Location from 'expo-location';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { db } from './firebaseConfig';
import styles from './Styles';

// --- TRUQUE PARA NÃO DAR ERRO NO PC ---
let MapView, Marker, Heatmap; // Adicionado Heatmap aqui
if (Platform.OS !== 'web') {
  const Maps = require('react-native-maps');
  MapView = Maps.default;
  Marker = Maps.Marker;
  Heatmap = Maps.Heatmap; // Extraindo o Heatmap da biblioteca
}

export default function TelaMapa({ navigation }) {
  const [location, setLocation] = useState(null);
  const [pontosCalor, setPontosCalor] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        let currentLocation = await Location.getCurrentPositionAsync({});
        setLocation(currentLocation.coords);
      }

      // BUSCA AS OCORRÊNCIAS E FORMATA PARA O MAPA DE CALOR
      const unsubscribe = db.collection('ocorrencias').onSnapshot(snapshot => {
        const pontos = snapshot.docs
          .map(doc => {
            const data = doc.data();
            // Só adiciona se tiver latitude e longitude
            if (data.latitude && data.longitude) {
              return {
                latitude: data.latitude,
                longitude: data.longitude,
                weight: 1, // O peso do ponto (1 ocorrência)
              };
            }
            return null;
          })
          .filter(p => p !== null); // Remove registros inválidos

        setPontosCalor(pontos);
        setLoading(false);
      });

      return () => unsubscribe();
    })();
  }, []);

  if (loading) {
    return (
      <View style={[styles.container_principal, { justifyContent: 'center' }]}>
        <ActivityIndicator size="large" color="#8e2de2" />
        <Text style={{ marginTop: 10 }}>Gerando mapa de calor...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      {Platform.OS === 'web' ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fce4ec' }}>
          <Text>Mapa de Calor ativo no celular</Text>
        </View>
      ) : (
        <MapView
          style={{ flex: 1 }}
          initialRegion={{
            latitude: location ? location.latitude : -3.7319,
            longitude: location ? location.longitude : -38.5267,
            latitudeDelta: 0.05,
            longitudeDelta: 0.05,
          }}
          showsUserLocation={true}
        >
          {/* O MAPA DE CALOR */}
          {pontosCalor.length > 0 && (
            <Heatmap
              points={pontosCalor}
              radius={40} // Define o tamanho da "mancha"
              opacity={0.7} // Transparência
              gradient={{
                colors: ["#00FF00", "#FFFF00", "#FF0000"], // Verde -> Amarelo -> Vermelho
                startPoints: [0.01, 0.25, 0.8], // Onde cada cor começa
                colorMapSize: 200,
              }}
            />
          )}
        </MapView>
      )}

      {/* BOTÃO VOLTAR */}
      <TouchableOpacity
        style={{ position: 'absolute', top: 50, left: 20, backgroundColor: 'white', padding: 10, borderRadius: 50, elevation: 5 }}
        onPress={() => navigation.goBack()}
      >
        <MaterialCommunityIcons name="arrow-left" size={30} color="#8e2de2" />
      </TouchableOpacity>

      {/* LEGENDA DO CALOR */}
      <View style={{ 
        position: 'absolute', 
        bottom: 30, 
        alignSelf: 'center', 
        backgroundColor: 'rgba(255,255,255,0.9)', 
        padding: 15, 
        borderRadius: 20, 
        width: '80%',
        alignItems: 'center'
      }}>
        <Text style={{ fontWeight: 'bold', color: '#d32f2f' }}>ZONAS DE ATENÇÃO</Text>
        <View style={{ flexDirection: 'row', width: '100%', height: 10, borderRadius: 5, marginTop: 5, overflow: 'hidden' }}>
          <View style={{ flex: 1, backgroundColor: 'green' }} />
          <View style={{ flex: 1, backgroundColor: 'yellow' }} />
          <View style={{ flex: 1, backgroundColor: 'red' }} />
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '100%' }}>
          <Text style={{ fontSize: 10 }}>Seguro</Text>
          <Text style={{ fontSize: 10 }}>Risco Alto</Text>
        </View>
      </View>
    </View>
  );
}