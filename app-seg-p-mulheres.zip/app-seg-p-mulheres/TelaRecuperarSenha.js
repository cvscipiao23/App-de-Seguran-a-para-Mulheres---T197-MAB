import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert } from 'react-native'; // <-- Alert adicionado
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './Styles';
import { auth } from './firebaseConfig'; // <-- Importando o Firebase Auth

function TelaRecuperarSenha({ navigation }) {

  const [email, setEmail] = useState('');

  // VALIDAR EMAIL
  const validarEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  // FUNÇÃO DO FIREBASE PARA RECUPERAR SENHA
  const recuperarSenha = () => {
    if (!validarEmail(email)) {
      Alert.alert('E-mail inválido', 'Digite um e-mail válido para continuar.');
      return;
    }

    // Chama o Firebase para enviar o e-mail de redefinição
    auth.sendPasswordResetEmail(email)
      .then(() => {
        // Sucesso!
        Alert.alert(
          'E-mail enviado!', 
          'Verifique sua caixa de entrada (e a pasta de spam) para redefinir sua senha.'
        );
        navigation.navigate('Login'); // Volta para o login após enviar
      })
      .catch((error) => {
        // Tratamento de erros
        if (error.code === 'auth/user-not-found') {
          Alert.alert('Erro', 'Não há nenhuma conta cadastrada com este e-mail.');
        } else {
          Alert.alert('Erro ao enviar', error.message);
        }
      });
  };

  return (

    <View style={styles.container_recuperar}>

      {/* LOGO */}
      <MaterialCommunityIcons
        name="map-marker"
        size={70}
        color="#8e2de2"
      />

      <Text style={styles.titulo_recuperar}>
        SafeHer
      </Text>

      <Text style={styles.subtitulo_recuperar}>
        Digite seu e-mail para recuperar a sua senha
      </Text>

      {/* INPUT EMAIL */}
      <TextInput
        style={styles.input_recuperar}
        placeholder="Seu e-mail"
        placeholderTextColor="#888"
        keyboardType="email-address"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
      />

      {/* BOTÃO */}
      <TouchableOpacity
        style={styles.botao_recuperar}
        onPress={recuperarSenha} // <-- Chamando a nova função aqui
      >

        <Text style={styles.texto_botao_recuperar}>
          ENVIAR
        </Text>

      </TouchableOpacity>

      {/* VOLTAR */}
      <TouchableOpacity
        onPress={() => navigation.navigate('Login')}
      >

        <Text style={styles.voltar_login}>
          Voltar para login
        </Text>

      </TouchableOpacity>

      {/* AJUDA */}
      <Text style={styles.ajuda_texto}>
        Precisa de ajuda?
      </Text>

      {/* REDES */}
      <View style={styles.redes_container}>

        <MaterialCommunityIcons
          name="facebook"
          size={30}
          color="#8e2de2"
        />

        <MaterialCommunityIcons
          name="instagram"
          size={30}
          color="#8e2de2"
        />

      </View>

    </View>

  );
}

export default TelaRecuperarSenha;