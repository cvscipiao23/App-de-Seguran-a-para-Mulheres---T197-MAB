import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ScrollView, KeyboardAvoidingView, Platform, TouchableWithoutFeedback, Keyboard } from 'react-native';
import * as Location from 'expo-location'; // <-- Importado para pegar a localização
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './Styles';
import { db, auth } from './firebaseConfig';

export default function TelaRegistrarOcorrencia({ navigation }) {
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [carregando, setCarregando] = useState(false);

  const salvarOcorrencia = async () => {
    if (!auth.currentUser) {
      Alert.alert("Erro", "Você precisa estar logada.");
      return;
    }

    if (titulo === '' || descricao === '') {
      Alert.alert("Atenção", "Preencha todos os campos.");
      return;
    }

    setCarregando(true);

    try {
      // CAPTURANDO A LOCALIZAÇÃO DO FATO
      let { status } = await Location.requestForegroundPermissionsAsync();
      let lat = null;
      let long = null;

      if (status === 'granted') {
        let loc = await Location.getCurrentPositionAsync({});
        lat = loc.coords.latitude;
        long = loc.coords.longitude;
      }

      await db.collection('ocorrencias').add({
        usuarioId: auth.currentUser.uid,
        titulo: titulo,
        descricao: descricao,
        latitude: lat, // Salvando a posição no mapa
        longitude: long, // Salvando a posição no mapa
        data: new Date().toLocaleString('pt-BR'),
        timestamp: new Date().getTime()
      });

      Alert.alert("Sucesso", "Ocorrência registrada e área mapeada!");
      navigation.goBack();
    } catch (error) {
      Alert.alert("Erro", error.message);
    } finally {
      setCarregando(false);
    }
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <ScrollView contentContainerStyle={[styles.container_contato, { flexGrow: 1, justifyContent: 'center' }]}>
          <View style={styles.card_cadastro}>
            <View style={styles.logoContainer}>
              <MaterialCommunityIcons name="alert-octagon" size={60} color="#d81b60" />
              <Text style={styles.titulo_principal}>Mapear Risco</Text>
            </View>

            <TextInput
              style={styles.input_cadastro}
              placeholder="Tipo de ocorrência (Ex: Assédio, Perseguição)"
              value={titulo}
              onChangeText={setTitulo}
            />

            <TextInput
              style={[styles.input_cadastro, { height: 120, textAlignVertical: 'top', paddingTop: 15 }]}
              placeholder="Detalhes (Opcional)..."
              multiline={true}
              value={descricao}
              onChangeText={setDescricao}
            />

            <TouchableOpacity style={styles.botao_cadastro} onPress={salvarOcorrencia} disabled={carregando}>
              <Text style={styles.texto_botao}>{carregando ? "MAPEANDO..." : "REGISTRAR E AVISAR"}</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}