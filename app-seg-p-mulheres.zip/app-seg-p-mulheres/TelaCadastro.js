import React, { useState } from 'react';
import {
  View,
  TextInput,
  Text,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Alert // <-- Alert adicionado aqui
} from 'react-native';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './Styles';
import { auth, db } from './firebaseConfig'; // <-- Firebase importado aqui

function TelaCadastro({ navigation }) {

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');

  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [mostrarConfirmarSenha, setMostrarConfirmarSenha] = useState(false);

  // VALIDAR EMAIL
  const validarEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  // FUNÇÃO DE CADASTRO COM FIREBASE
  const fazerCadastro = () => {
    // 1. Validações locais
    if (!nome || !email || !senha || !confirmarSenha) {
      Alert.alert('Campos vazios', 'Por favor, preencha todos os campos.');
      return;
    }

    if (!validarEmail(email)) {
      Alert.alert('E-mail inválido', 'Digite um e-mail válido.');
      return;
    }

    if (senha !== confirmarSenha) {
      Alert.alert('Senhas diferentes', 'As senhas digitadas não coincidem.');
      return;
    }

    if (senha.length < 6) {
      Alert.alert('Senha fraca', 'A senha deve ter pelo menos 6 caracteres.');
      return;
    }

    // 2. Criação da conta no Firebase Authentication
    auth.createUserWithEmailAndPassword(email, senha)
      .then((userCredential) => {
        // Sucesso na criação do login! Pegamos o ID da usuária
        const user = userCredential.user;

        // 3. Salvando os dados extras (Nome) no Firestore
        db.collection('usuarias').doc(user.uid).set({
          nome: nome,
          email: email,
          dataCadastro: new Date()
        })
        .then(() => {
          Alert.alert('Sucesso!', 'Conta criada com sucesso.');
          // Navega para a tela principal (já logada)
          navigation.navigate('Principal'); 
        })
        .catch((error) => {
          console.error("Erro ao salvar no banco: ", error);
          Alert.alert('Aviso', 'Conta criada, mas houve um erro ao salvar o nome.');
        });
      })
      .catch((error) => {
        // Tratamento de erros do Firebase (ex: e-mail já existe)
        if (error.code === 'auth/email-already-in-use') {
          Alert.alert('Erro', 'Este e-mail já está sendo usado por outra conta.');
        } else {
          Alert.alert('Erro ao cadastrar', error.message);
        }
      });
  };

  return (
    <KeyboardAvoidingView
      style={styles.container_contato}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        contentContainerStyle={styles.scroll_cadastro}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.card_cadastro}>

          {/* LOGO */}
          <View style={styles.logoContainer}>
            <MaterialCommunityIcons
              name="map-marker"
              size={40}
              color="#8e2de2"
            />
            <Text style={styles.logoText}>SafeHer</Text>
            <Text style={styles.texto}>Cadastre Aqui</Text>
          </View>

          {/* NOME */}
          <TextInput
            style={styles.input_cadastro}
            placeholder="Nome Completo"
            value={nome}
            onChangeText={setNome}
          />

          {/* EMAIL */}
          <TextInput
            style={styles.input_cadastro}
            placeholder="E-mail"
            keyboardType="email-address"
            autoCapitalize="none"
            value={email}
            onChangeText={setEmail}
          />

          {/* SENHA */}
          <View style={styles.container_senha}>
            <TextInput
              style={styles.input_senha}
              placeholder="Senha"
              secureTextEntry={!mostrarSenha}
              value={senha}
              onChangeText={setSenha}
            />
            <TouchableOpacity onPress={() => setMostrarSenha(!mostrarSenha)}>
              <MaterialCommunityIcons
                name={mostrarSenha ? 'eye-off' : 'eye'}
                size={24}
                color="gray"
              />
            </TouchableOpacity>
          </View>

          {/* CONFIRMAR SENHA */}
          <View style={styles.container_senha}>
            <TextInput
              style={styles.input_senha}
              placeholder="Confirmar Senha"
              secureTextEntry={!mostrarConfirmarSenha}
              value={confirmarSenha}
              onChangeText={setConfirmarSenha}
            />
            <TouchableOpacity onPress={() => setMostrarConfirmarSenha(!mostrarConfirmarSenha)}>
              <MaterialCommunityIcons
                name={mostrarConfirmarSenha ? 'eye-off' : 'eye'}
                size={24}
                color="gray"
              />
            </TouchableOpacity>
          </View>

          {/* BOTÃO CADASTRAR */}
          <TouchableOpacity
            style={styles.botao_cadastro}
            onPress={fazerCadastro} // <-- Chamando a nova função aqui
          >
            <Text style={styles.texto_botao}>Cadastrar</Text>
          </TouchableOpacity>

          {/* VOLTAR LOGIN */}
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={styles.criarConta}
          >
            <Text style={styles.texto_criar}>Já tem uma conta? Entre aqui</Text>
          </TouchableOpacity>

        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

export default TelaCadastro;