import firebase from 'firebase';
import 'firebase/firestore';
import 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyDxx6BlifXNxY9k1BXuGbiw8hjMEDznRgI",
  authDomain: "safeher-5f734.firebaseapp.com",
  projectId: "safeher-5f734",
  storageBucket: "safeher-5f734.firebasestorage.app",
  messagingSenderId: "511391418726",
  appId: "1:511391418726:web:bc76587af302bea4e120a7",
  measurementId: "G-4VEH1NCN4H"
};

if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const db = firebase.firestore();
const auth = firebase.auth(); 
export { db, auth }; 