import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({

  // CONTAINER GERAL
  container: {
    flex: 1,
    backgroundColor: 'pink',
    justifyContent: 'center',
    alignItems: 'center',
  },

  // CONTAINER CONTATO
  container_contato: {
    flex: 1,
    backgroundColor: 'pink',
  },

  // CONTAINER PRINCIPAL
  container_principal: {
    flex: 1,
    backgroundColor: 'pink',
    justifyContent: 'center',
    alignItems: 'center',
  },

  // CONTAINER RECUPERAR
  container_recuperar: {
    flex: 1,
    backgroundColor: 'pink',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
  },

  // CARD HOME
  card_home: {
    width: '80%',
    backgroundColor: 'pink',
    borderRadius: 25,
    padding: 20,
    alignItems: 'center',
  },

  // CARD LOGIN
  card_login: {
    width: '75%',
    backgroundColor: 'pink',
    borderRadius: 25,
    padding: 20,
    alignSelf: 'center',
    marginTop: 120,
  },

  // CARD CADASTRO
  card_cadastro: {
    width: '75%',
    backgroundColor: 'pink',
    borderRadius: 25,
    padding: 20,
    alignSelf: 'center',
  },

  // CARD PRINCIPAL
  card_principal: {
    width: '85%',
    backgroundColor: 'pink',
    borderRadius: 25,
    padding: 20,
    alignItems: 'center',
  },

  // LOGO
  logoContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },

  logoText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#8e2de2',
  },

  // TEXTOS
  texto: {
    fontSize: 18,
    color: '#6a1b9a',
    marginBottom: 20,
    textAlign: 'center',
    fontWeight: '500',
  },

  idade: {
    marginTop: 20,
    color: '#6a1b9a',
    fontSize: 14,
    textAlign: 'center',
  },

  titulo_recuperar: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#8e2de2',
    marginTop: 10,
  },

  subtitulo_recuperar: {
    color: '#6a1b9a',
    marginTop: 15,
    marginBottom: 30,
    textAlign: 'center',
    fontSize: 15,
    width: '90%',
  },

  ajuda_texto: {
    color: '#6a1b9a',
    marginTop: 35,
    fontSize: 13,
  },

  // INPUT LOGIN
  input_login: {
    width: '100%',
    height: 50,
    backgroundColor: '#eee',
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 15,
    fontSize: 16,
    color: '#333',
  },

  // INPUT CADASTRO
  input_cadastro: {
    width: '100%',
    height: 50,
    backgroundColor: '#eee',
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 15,
    fontSize: 16,
    color: '#333',
  },

  // INPUT RECUPERAR
  input_recuperar: {
    width: '100%',
    height: 55,
    backgroundColor: '#eee',
    borderRadius: 12,
    paddingHorizontal: 15,
    marginBottom: 20,
    fontSize: 16,
    color: '#333',
  },

  // INPUT SENHA
  container_senha: {
    width: '100%',
    height: 50,
    backgroundColor: '#eee',
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 15,

    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  input_senha: {
    flex: 1,
    height: 50,
    fontSize: 16,
    color: '#333',
    paddingRight: 10,
  },

  // SCROLL
  scroll_cadastro: {
    flexGrow: 1,
    justifyContent: 'center',
  },

  // BOTÃO PRINCIPAL
  botao: {
    backgroundColor: '#8e2de2',
    height: 55,
    width: '100%',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },

  // BOTÃO OUTLINE
  botao2: {
    borderWidth: 2,
    borderColor: '#8e2de2',
    height: 55,
    width: '100%',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 15,
  },

  // BOTÃO CADASTRO
  botao_cadastro: {
    backgroundColor: '#8e2de2',
    height: 55,
    width: '100%',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 15,
  },

  // BOTÃO RECUPERAR
  botao_recuperar: {
    width: '100%',
    height: 55,
    backgroundColor: '#8e2de2',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // BOTÃO EMERGÊNCIA
  botao_emergencia: {
  width: '100%',
  backgroundColor: '#d32f2f',
  paddingVertical: 20,
  borderRadius: 25,
  alignItems: 'center',
  justifyContent: 'center',

  marginTop: 70, // AFASTA DOS OUTROS BOTÕES
  marginBottom: 20,
},

  texto_emergencia: {
    color: 'white',
    fontSize: 22,
    fontWeight: 'bold',
  },

  titulo_principal: {
  fontSize: 28,
  fontWeight: 'bold',
  color: '#8e2de2',
  marginBottom: 40,
  textAlign: 'center',
},

  // LINHA BOTÕES
  linha_botoes: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 20,
  },

  // BOTÃO REGISTRAR
  botao_registrar: {
    width: '48%',
    backgroundColor: '#d81b60',
    paddingVertical: 20,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },

  // BOTÃO MAPA
  botao_mapa_inicio: {
    width: '48%',
    backgroundColor: '#26a69a',
    paddingVertical: 20,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },

  // TEXTO BOTÃO INÍCIO
  texto_botao_inicio: {
    color: 'white',
    textAlign: 'center',
    marginTop: 8,
    fontWeight: 'bold',
    fontSize: 15,
  },

  // BOTÃO CONTATOS
  botao_contatos: {
  width: '48%',
  backgroundColor: '#e53935',
  paddingVertical: 25,
  borderRadius: 20,
  alignItems: 'center',
  justifyContent: 'center',

  alignSelf: 'center', // CENTRALIZA
  marginTop: 15, // FICA ABAIXO DOS DOIS BOTÕES
},

  texto_contatos: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 18,
    marginLeft: 10,
  },

  // TEXTOS BOTÕES
  texto_botao: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
    textTransform: 'uppercase',
  },

  texto_botao_outline: {
    color: '#8e2de2',
    fontWeight: 'bold',
    fontSize: 16,
    textTransform: 'uppercase',
  },

  texto_botao_recuperar: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
    textTransform: 'uppercase',
  },

  // LINKS
  criarConta: {
    marginTop: 15,
    alignItems: 'center',
  },

  texto_criar: {
    color: '#6a1b9a',
    textDecorationLine: 'underline',
    fontWeight: '500',
    textAlign: 'center',
  },

  texto_esqueceu: {
    color: '#6a1b9a',
    textAlign: 'center',
    marginTop: 10,
    textDecorationLine: 'underline',
  },

  voltar_login: {
    color: '#6a1b9a',
    textDecorationLine: 'underline',
    marginTop: 25,
    fontWeight: '500',
  },

  // SOCIAL
  socialContainer: {
    flexDirection: 'row',
    marginTop: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },

  redes_container: {
    flexDirection: 'row',
    marginTop: 15,
    gap: 20,
  },

});

export default styles;