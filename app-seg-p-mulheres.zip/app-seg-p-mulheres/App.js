import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import TelaHome from './TelaHome';
import TelaLogin from './TelaLogin';
import TelaCadastro from './TelaCadastro';
import TelaPrincipal from './TelaPrincipal'; 
import TelaRecuperarSenha from './TelaRecuperarSenha';
import TelaMapa from './TelaMapa';
import TelaRegistrarOcorrencia from './TelaRegistrarOcorrencia';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={TelaHome} />
        <Stack.Screen name="Login" component={TelaLogin} />
        <Stack.Screen name="Cadastro" component={TelaCadastro} />
        <Stack.Screen name="Principal" component={TelaPrincipal} />
        <Stack.Screen name="RecuperarSenha" component={TelaRecuperarSenha} />
        <Stack.Screen name="Mapa" component={TelaMapa} />
        <Stack.Screen name="RegistrarOcorrencia" component={TelaRegistrarOcorrencia} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
