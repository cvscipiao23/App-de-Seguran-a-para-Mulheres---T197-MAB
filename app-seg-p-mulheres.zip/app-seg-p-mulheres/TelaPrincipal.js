import React, { useState, useEffect } from 'react'; 
import { View, Text, TouchableOpacity, Linking, Alert } from 'react-native';
import * as Contacts from 'expo-contacts';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './Styles';
import { db, auth } from './firebaseConfig'; 

function TelaPrincipal({ navigation }) {
  const [nomeUsuario, setNomeUsuario] = useState('Usuária');

 
  useEffect(() => {
    const buscarNome = async () => {
      const user = auth.currentUser;
      
      if (user) {
        try {
          // Busca no Firestore o documento na coleção 'usuarias' que tem o ID do usuário logado
          const doc = await db.collection('usuarias').doc(user.uid).get();
          
          if (doc.exists) {
            // Pega o campo 'nome' que você salvou lá na Tela de Cadastro
            const dados = doc.data();
            setNomeUsuario(dados.nome); 
          }
        } catch (error) {
          console.log("Erro ao buscar nome:", error);
        }
      }
    };

    buscarNome();
  }, []);

  // FUNÇÃO PARA SELECIONAR CONTATO E LIGAR
  const selecionarELigar = async () => {
    const { status } = await Contacts.requestPermissionsAsync();
    if (status === 'granted') {
      const contact = await Contacts.presentContactPickerAsync();
      if (contact && contact.phoneNumbers && contact.phoneNumbers.length > 0) {
        const numeroTelefone = contact.phoneNumbers[0].number;
        Linking.openURL(`tel:${numeroTelefone}`);
      } else if (contact) {
        Alert.alert("Aviso", "Este contato não possui um número de telefone.");
      }
    } else {
      Alert.alert("Permissão negada", "Precisamos de permissão para acessar os contatos.");
    }
  };

  return (
    <View style={styles.container_principal}>
      <View style={styles.card_principal}>

        {/* TÍTULO PERSONALIZADO */}
        <Text style={styles.titulo_principal}>
            Olá, {nomeUsuario}!
        </Text>

        <View style={styles.linha_botoes}>
          {/* REGISTRAR */}
          <TouchableOpacity 
            style={styles.botao_registrar}
            onPress={() => navigation.navigate('RegistrarOcorrencia')}
          >
            <MaterialCommunityIcons name="file-document" size={30} color="white" />
            <Text style={styles.texto_botao_inicio}>Registrar{'\n'}Ocorrência</Text>
          </TouchableOpacity>

          {/* MAPA */}
          <TouchableOpacity
            style={styles.botao_mapa_inicio}
            onPress={() => navigation.navigate('Mapa')}
          >
            <MaterialCommunityIcons name="map-marker" size={30} color="white" />
            <Text style={styles.texto_botao_inicio}>Mapa</Text>
          </TouchableOpacity>
        </View>

        {/* CONTATOS */}
        <TouchableOpacity 
          style={styles.botao_contatos}
          onPress={selecionarELigar}
        >
          <MaterialCommunityIcons name="account" size={30} color="white" />
          <Text style={styles.texto_botao_inicio}>Contatos</Text>
        </TouchableOpacity>

        {/* EMERGÊNCIA */}
        <TouchableOpacity 
          style={styles.botao_emergencia}
          onPress={() => Linking.openURL('tel:180')} 
        >
          <MaterialCommunityIcons name="alert" size={40} color="white" />
          <Text style={styles.texto_emergencia}>EMERGÊNCIA</Text>
        </TouchableOpacity>

      </View>
    </View>
  );
}

export default TelaPrincipal;