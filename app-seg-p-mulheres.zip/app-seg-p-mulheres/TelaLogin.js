import React, { useState } from 'react';
import { View, TextInput, Text, TouchableOpacity, Alert } from 'react-native'; // <-- Alert adicionado
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './Styles';
import { auth } from './firebaseConfig'; // <-- Importando o Firebase Auth

function TelaLogin({ navigation }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [mostrarSenha, setMostrarSenha] = useState(false);

  // VALIDADOR DE EMAIL
  const validarEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  // FUNÇÃO DE LOGIN DO FIREBASE
  const fazerLogin = () => {
    if (!validarEmail(email)) {
      Alert.alert('E-mail inválido', 'Por favor, digite um e-mail válido.');
      return;
    }

    if (senha === '') {
      Alert.alert('Senha vazia', 'Por favor, digite sua senha.');
      return;
    }

    // Chama o Firebase para verificar email e senha
    auth.signInWithEmailAndPassword(email, senha)
      .then((userCredential) => {
        // Deu certo! O Firebase confirmou o login.
        navigation.navigate('Principal');
      })
      .catch((error) => {
        // Deu erro (senha errada, email não existe, etc.)
        console.error(error);
        Alert.alert('Erro ao entrar', 'E-mail ou senha incorretos. Verifique seus dados e tente novamente.');
      });
  };

  return (
    <View style={styles.container_contato}>
      <View style={styles.card_login}>
        
        <View style={styles.logoContainer}>
          <MaterialCommunityIcons name="map-marker" size={40} color="#8e2de2" />
          <Text style={styles.logoText}>SafeHer</Text>
        </View>

        <TextInput
          style={styles.input_login}
          placeholder="E-mail"
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />

        <View style={styles.container_senha}>
          <TextInput
            style={styles.input_senha}
            placeholder="Senha"
            value={senha}
            onChangeText={setSenha}
            secureTextEntry={!mostrarSenha}
          />

          <TouchableOpacity onPress={() => setMostrarSenha(!mostrarSenha)}>
            <MaterialCommunityIcons
              name={mostrarSenha ? 'eye-off' : 'eye'}
              size={25}
              color="gray"
            />
          </TouchableOpacity>
        </View>

        <TouchableOpacity onPress={() => navigation.navigate('RecuperarSenha')}>
          <Text style={styles.texto_esqueceu}>Esqueceu sua senha?</Text>
        </TouchableOpacity>

        {/* Botão de Entrar atualizado para chamar a função fazerLogin */}
        <TouchableOpacity style={styles.botao} onPress={fazerLogin}>
          <Text style={styles.texto_botao}>Entrar</Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => navigation.navigate('Cadastro')}
          style={styles.criarConta}
        >
          <Text style={styles.texto_criar}>Criar conta</Text>
        </TouchableOpacity>

      </View>
    </View>
  );
}

export default TelaLogin;